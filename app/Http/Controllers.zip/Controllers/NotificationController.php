<?php

namespace App\Http\Controllers;

use App\Models\Notification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class NotificationController extends Controller
{
    /**
     * Tandai satu notifikasi sebagai dibaca
     */
    public function read($id)
    {
        try {
            $notification = Notification::findOrFail($id);
            $notification->update(['is_read' => true]);
            
            // Redirect ke URL yang dituju
            return redirect($notification->url ?? route('dashboard'));
            
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Notifikasi tidak ditemukan');
        }
    }
    
    /**
     * Tandai semua notifikasi sebagai dibaca
     */
    public function readAll(Request $request)
    {
        try {
            // Update semua notifikasi yang belum dibaca
            $updated = Notification::where('is_read', false)->update(['is_read' => true]);
            
            if ($request->ajax() || $request->wantsJson()) {
                return response()->json([
                    'success' => true,
                    'message' => "{$updated} notifikasi telah ditandai dibaca",
                    'count' => $updated
                ]);
            }
            
            return redirect()->back()->with('success', 'Semua notifikasi telah ditandai dibaca');
            
        } catch (\Exception $e) {
            if ($request->ajax() || $request->wantsJson()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Gagal menandai notifikasi: ' . $e->getMessage()
                ], 500);
            }
            
            return redirect()->back()->with('error', 'Gagal menandai notifikasi');
        }
    }
    
    /**
     * Ambil notifikasi untuk AJAX (opsional)
     */
    public function getUnreadCount(Request $request)
    {
        $count = Notification::where('is_read', false)->count();
        
        // Ambil juga notifikasi stok terbaru
        $recentStockNotif = Notification::where('type', 'stock')
            ->where('is_read', false)
            ->latest()
            ->first();
        
        return response()->json([
            'count' => $count,
            'has_stock_alert' => $recentStockNotif ? true : false,
            'stock_message' => $recentStockNotif ? $recentStockNotif->message : null
        ]);
    }
    
    /**
     * Halaman semua notifikasi (opsional)
     */
    public function index()
    {
        $notifications = Notification::latest()->paginate(20);
        return view('backend.notifications.index', compact('notifications'));
    }
}