<?php

namespace App\Http\Controllers;

use App\Models\MemberRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class MemberRequestController extends Controller
{
public function store(Request $request)
{
    $user = auth()->user();

    // Cek duplikasi
    $existing = MemberRequest::where('user_id', $user->user_id)
                    ->whereIn('status', ['pending', 'approved'])
                    ->first();

    if ($existing) {
        return redirect()->back()->with('info', 'Anda sudah mengajukan pendaftaran member.');
    }

    MemberRequest::create([
        'user_id' => $user->user_id,
        'status'  => 'pending',
    ]);

    \App\Models\Notification::create([
    'type'    => 'member',
    'title'   => '👤 Pengajuan Member Baru',
    'message' => $user->username . ' mengajukan pendaftaran member.',
    'url'     => '/admin/member-requests',
    'is_read' => 0,
    ]);

    return redirect()->route('home')->with('success', 'Pengajuan member berhasil dikirim!');
}

    // ADMIN
public function adminIndex(Request $request)
{
    $query = MemberRequest::with('user');

    if ($request->filled('status')) {
        $query->where('status', $request->status);
    }

    // Menggunakan paginate 10 agar seragam dengan tabel lain
    $requests = $query->latest()->paginate(10)->withQueryString();

    return view('member-requests.index', compact('requests'));
}

    public function approve($id)
    {
        $memberRequest = MemberRequest::with('user')->findOrFail($id);

        if ($memberRequest->status !== 'pending') {
            return back()->with('error', 'Pengajuan ini sudah diproses sebelumnya.');
        }

        $memberRequest->update([
            'status'       => 'approved',
            'processed_at' => now(),
        ]);

        // Set user jadi member
        $memberRequest->user->update(['is_member' => 1]);

        \App\Models\Notification::create([
    'type'    => 'member',
    'title'   => '✅ Member Disetujui',
    'message' => $memberRequest->user->username . ' telah disetujui menjadi member.',
    'url'     => '/admin/member-requests',
    'is_read' => 0,
]);

        return back()->with('success', "{$memberRequest->user->username} berhasil disetujui menjadi member.");
    }

    public function reject($id)                  // ← hapus Request $request, tidak perlu
    {
        $memberRequest = MemberRequest::with('user')->findOrFail($id);

        if ($memberRequest->status !== 'pending') {
            return back()->with('error', 'Pengajuan ini sudah diproses sebelumnya.');
        }

        $memberRequest->update([
            'status'       => 'rejected',
            'processed_at' => now(),
        ]);
\App\Models\Notification::create([
    'type'    => 'member',
    'title'   => '❌ Member Ditolak',
    'message' => 'Pengajuan ' . $memberRequest->user->username . ' telah ditolak.',
    'url'     => '/admin/member-requests',
    'is_read' => 0,
]);
        return back()->with('success', "Pengajuan {$memberRequest->user->username} berhasil ditolak.");
    }
}