<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('shippings', function (Blueprint $table) {
            $table->id('shipping_id');

            $table->foreignId('user_id')->constrained('users', 'user_id');

            $table->string('label'); // Rumah, Kantor
            $table->text('address');

        $table->string('province_id');
        $table->string('city_id');
        $table->string('district_id');
        $table->string('village_id');
                    // TAMBAH: Data penerima
            $table->string('recipient_name')->nullable();
            $table->string('recipient_phone')->nullable();
            
            // TAMBAH: Kode pos
            $table->string('postal_code')->nullable();

            $table->boolean('is_default')->default(false);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('shippings');
    }
};
