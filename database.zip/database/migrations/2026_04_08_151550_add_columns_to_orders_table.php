<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('orders', function (Blueprint $table) {
            // Timestamp perubahan status
            $table->timestamp('ready_at')->nullable()->after('paid_at');
            $table->timestamp('shipped_at')->nullable()->after('ready_at');
            $table->timestamp('delivered_at')->nullable()->after('shipped_at');
            $table->timestamp('completed_at')->nullable()->after('delivered_at');

            // Untuk pengiriman ekspedisi
            $table->string('tracking_number')->nullable()->after('completed_at');

            // Untuk pembayaran cash
            $table->decimal('cash_amount_received', 15, 2)->nullable()->after('tracking_number');
            $table->decimal('cash_change', 15, 2)->nullable()->after('cash_amount_received');

            // Untuk admin manual order
            $table->unsignedBigInteger('created_by')->nullable()->after('cash_change');
        });
    }

    public function down(): void
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->dropColumn([
                'ready_at',
                'shipped_at',
                'delivered_at',
                'completed_at',
                'tracking_number',
                'cash_amount_received',
                'cash_change',
                'created_by',
            ]);
        });
    }
};