<aside 
    id="sidebar" 
    :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'"
    class="fixed top-0 left-0 w-64 h-full bg-[#0f172a] text-slate-300 flex flex-col z-50 transition-transform duration-300 ease-in-out md:relative md:translate-x-0 border-r border-slate-800 shadow-xl md:shadow-none overflow-y-auto"
    style="scrollbar-width: thin; scrollbar-color: rgba(255,255,255,0.08) transparent;"
>

    {{-- Subtle grid texture overlay --}}
    <div class="pointer-events-none absolute inset-0 opacity-[0.03]" style="background-image: linear-gradient(rgba(148,163,184,1) 1px, transparent 1px), linear-gradient(90deg, rgba(148,163,184,1) 1px, transparent 1px); background-size: 32px 32px;"></div>

    {{-- ─── Logo / Brand ──────────────────────────────────────── --}}
    <div class="relative h-[68px] flex items-center px-5 shrink-0" style="border-bottom: 1px solid rgba(255,255,255,0.05);">
        <div class="flex items-center gap-3">
            <div class="w-9 h-9 rounded-xl flex items-center justify-center shrink-0" 
                 style="background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%); box-shadow: 0 4px 14px rgba(37,99,235,0.45);">
                <i class="fas fa-print text-white text-[15px]"></i>
            </div>
            <div class="flex flex-col leading-none">
                <span class="text-white font-bold tracking-tight text-[15px]">PrintMaster</span>
                <span class="text-[9px] font-extrabold uppercase tracking-[0.18em] text-slate-400 mt-[3px]">Digital Printing</span>
            </div>
        </div>

        {{-- Mobile close button --}}
        <button @click="sidebarOpen = false" class="md:hidden ml-auto text-slate-500 hover:text-white transition-colors p-1">
            <i class="fas fa-times text-base"></i>
        </button>
    </div>

    {{-- ─── Navigation ─────────────────────────────────────────── --}}
    <nav class="flex-1 overflow-y-auto py-5 px-3 space-y-6" 
         style="scrollbar-width: thin; scrollbar-color: rgba(255,255,255,0.08) transparent;">

        {{-- Main --}}
        <div>
            <p class="px-3 mb-2 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">Main</p>
            <div class="space-y-0.5">

                <a href="{{ route('dashboard') }}" 
                   class="nav-item flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-[13px] font-medium transition-all duration-150 group
                         {{ request()->routeIs('dashboard') ? 'active' : '' }}">
                    <i class="fas fa-desktop w-4 text-center text-[13px] shrink-0 transition-colors"></i>
                    <span>Dashboard Admin</span>
                </a>

                <a href="{{ route('admin.orders.index') }}" 
                   class="nav-item flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-[13px] font-medium transition-all duration-150 group
                         {{ request()->routeIs('admin.orders.*') ? 'active' : '' }}">
                    <i class="fas fa-shopping-cart w-4 text-center text-[13px] shrink-0 transition-colors"></i>
                    <span class="flex-1">Pesanan Masuk</span>
                    <span class="text-[10px] font-extrabold px-1.5 py-0.5 rounded-md" 
                          style="background: #2563eb; color: #fff; letter-spacing: 0.05em; box-shadow: 0 2px 6px rgba(37,99,235,0.4);">{{ \App\Models\Orders::where('status', 'paid')->count() }}</span>
                </a>

            </div>
        </div>

        {{-- Produksi & Stok --}}
        @php $openProduksi = request()->is('products*','categories*','materials*','units*','stocklogs*') ? 'true' : 'false'; @endphp
        <div x-data="{ open: {{ $openProduksi }} }">
            <p class="px-3 mb-2 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">Produksi & Stok</p>

            <button type="button" @click="open = !open"
                    class="nav-item w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-[13px] font-medium transition-all duration-150 text-left">
                <i class="fas fa-database w-4 text-center text-[13px] shrink-0"></i>
                <span class="flex-1">Master Data</span>
                <svg :class="open ? 'rotate-90 text-blue-400' : 'rotate-0 text-slate-500'"
                     class="w-3 h-3 shrink-0 transition-transform duration-200"
                     fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/>
                </svg>
            </button>

            <div x-show="open"
                 x-transition:enter="transition ease-out duration-200"
                 x-transition:enter-start="opacity-0 scale-y-95 origin-top"
                 x-transition:enter-end="opacity-100 scale-y-100 origin-top"
                 x-transition:leave="transition ease-in duration-150"
                 x-transition:leave-start="opacity-100 scale-y-100 origin-top"
                 x-transition:leave-end="opacity-0 scale-y-95 origin-top"
                 class="mt-1 ml-3 pl-4 space-y-0.5"
                 style="border-left: 1px solid rgba(255,255,255,0.07); display: none;">

                <a href="{{ route('products.index') }}"
                   class="sub-nav-item flex items-center gap-2 px-2 py-2 text-[12.5px] rounded-md transition-all duration-150 {{ request()->routeIs('products.*') ? 'active' : '' }}">
                    <i class="fas fa-box w-3.5 text-center text-[11px] opacity-70 shrink-0"></i><span>Katalog Produk</span>
                </a>
                <a href="{{ route('categories.index') }}"
                   class="sub-nav-item flex items-center gap-2 px-2 py-2 text-[12.5px] rounded-md transition-all duration-150 {{ request()->routeIs('categories.*') ? 'active' : '' }}">
                    <i class="fas fa-tag w-3.5 text-center text-[11px] opacity-70 shrink-0"></i><span>Kategori Cetak</span>
                </a>
                <a href="{{ route('materials.index') }}"
                   class="sub-nav-item flex items-center gap-2 px-2 py-2 text-[12.5px] rounded-md transition-all duration-150 {{ request()->routeIs('materials.*') ? 'active' : '' }}">
                    <i class="fas fa-layer-group w-3.5 text-center text-[11px] opacity-70 shrink-0"></i><span>Stok Bahan</span>
                </a>
                <a href="{{ route('units.index') }}"
                   class="sub-nav-item flex items-center gap-2 px-2 py-2 text-[12.5px] rounded-md transition-all duration-150 {{ request()->routeIs('units.*') ? 'active' : '' }}">
                    <i class="fas fa-ruler w-3.5 text-center text-[11px] opacity-70 shrink-0"></i><span>Satuan Unit</span>
                </a>
                <a href="{{ route('stocklogs.index') }}"
                   class="sub-nav-item flex items-center gap-2 px-2 py-2 text-[12.5px] rounded-md transition-all duration-150 {{ request()->routeIs('stocklogs.*') ? 'active' : '' }}">
                    <i class="fas fa-history w-3.5 text-center text-[11px] opacity-70 shrink-0"></i><span>Log Riwayat Stok</span>
                </a>
            </div>
        </div>

        {{-- Affiliate & Keuangan --}}
        @php $openAffiliate = request()->is('member-requests*','withdrawals*','admin-saldo-logs*') ? 'true' : 'false'; @endphp
        <div x-data="{ open: {{ $openAffiliate }} }">
            <p class="px-3 mb-2 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">Affiliate & Keuangan</p>

            <button type="button" @click="open = !open"
                    class="nav-item w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-[13px] font-medium transition-all duration-150 text-left">
                <i class="fas fa-users-cog w-4 text-center text-[13px] shrink-0"></i>
                <span class="flex-1">Manajemen Member</span>
                <svg :class="open ? 'rotate-90 text-blue-400' : 'rotate-0 text-slate-500'"
                     class="w-3 h-3 shrink-0 transition-transform duration-200"
                     fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/>
                </svg>
            </button>

            <div x-show="open"
                 x-transition:enter="transition ease-out duration-200"
                 x-transition:enter-start="opacity-0 scale-y-95 origin-top"
                 x-transition:enter-end="opacity-100 scale-y-100 origin-top"
                 x-transition:leave="transition ease-in duration-150"
                 x-transition:leave-start="opacity-100 scale-y-100 origin-top"
                 x-transition:leave-end="opacity-0 scale-y-95 origin-top"
                 class="mt-1 ml-3 pl-4 space-y-0.5"
                 style="border-left: 1px solid rgba(255,255,255,0.07); display: none;">

                <a href="{{ route('member-requests.index') }}"
                   class="sub-nav-item flex items-center gap-2 px-2 py-2 text-[12.5px] rounded-md transition-all duration-150 {{ request()->routeIs('member-requests.*') ? 'active' : '' }}">
                    <i class="fas fa-user-clock w-3.5 text-center text-[11px] opacity-70 shrink-0"></i><span>Request Member</span>
                    <span class="text-[10px] font-extrabold px-1.5 py-0.5 rounded-md" 
                          style="background: #2563eb; color: #fff; letter-spacing: 0.05em; box-shadow: 0 2px 6px rgba(37,99,235,0.4);">{{ \App\Models\MemberRequest::where('status', 'pending')->count() }}</span>
                </a>
                <a href="{{ route('admin.withdrawals.index') }}"
                   class="sub-nav-item flex items-center gap-2 px-2 py-2 text-[12.5px] rounded-md transition-all duration-150 {{ request()->routeIs('admin.withdrawals.*') ? 'active' : '' }}">
                    <i class="fas fa-wallet w-3.5 text-center text-[11px] opacity-70 shrink-0"></i><span>Pencairan Komisi</span>
                </a>
                <a href="{{ route('admin.saldo-logs.index') }}"
                   class="sub-nav-item flex items-center gap-2 px-2 py-2 text-[12.5px] rounded-md transition-all duration-150 {{ request()->routeIs('admin.saldo-logs.index') ? 'active' : '' }}">
                    <i class="fas fa-receipt w-3.5 text-center text-[11px] opacity-70 shrink-0"></i><span>Log Saldo Member</span>
                </a>
            </div>
        </div>

        {{-- Konfigurasi --}}
        <div>
            <p class="px-3 mb-2 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">Konfigurasi</p>
            <div class="space-y-0.5">

                <a href="{{ route('users.index') }}" 
                   class="nav-item flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-[13px] font-medium transition-all duration-150 group
                         {{ request()->routeIs('users.*') ? 'active' : '' }}">
                    <i class="fas fa-user-shield w-4 text-center text-[13px] shrink-0"></i>
                    <span>Kelola Akun</span>
                </a>

                <a href="{{ route('heros.index') }}" 
                   class="nav-item flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-[13px] font-medium transition-all duration-150 group
                         {{ request()->routeIs('heros.*') ? 'active' : '' }}">
                    <i class="fas fa-images w-4 text-center text-[13px] shrink-0"></i>
                    <span>Banner Promo</span>
                </a>

                <a href="{{ route('faqs.index') }}" 
                   class="nav-item flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-[13px] font-medium transition-all duration-150 group
                         {{ request()->routeIs('faqs.*') ? 'active' : '' }}">
                    <i class="fas fa-question-circle w-4 text-center text-[13px] shrink-0"></i>
                    <span>FAQ</span>
                </a>

            </div>
        </div>

    </nav>

</aside>