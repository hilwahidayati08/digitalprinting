{{-- ═══════════════════════════════════════════════════════════════
     partials/admin/pagination.blade.php

     CARA PAKAI (dua opsi):

     1. Langsung di view:
        @include('partials.admin.pagination', ['paginator' => $items])

     2. Via @stack di layout (sudah ada @stack('pagination')):
        @push('pagination')
            @include('partials.admin.pagination', ['paginator' => $items])
        @endpush
═══════════════════════════════════════════════════════════════ --}}

@if(isset($paginator) && $paginator->hasPages())

<div class="mt-6 flex flex-col sm:flex-row items-center justify-between gap-3">

    {{-- ─── Info: Menampilkan X–Y dari Z ──────────────────────── --}}
    <p class="text-[12.5px] text-gray-500 shrink-0">
        Menampilkan
        <span class="font-semibold text-gray-700">{{ $paginator->firstItem() }}</span>
        &ndash;
        <span class="font-semibold text-gray-700">{{ $paginator->lastItem() }}</span>
        dari
        <span class="font-semibold text-gray-700">{{ $paginator->total() }}</span>
        data
    </p>

    {{-- ─── Pagination Links ────────────────────────────────────── --}}
    <nav class="flex items-center gap-1" aria-label="Pagination">

        {{-- Prev --}}
        @if($paginator->onFirstPage())
            <span class="inline-flex items-center justify-center w-8 h-8 rounded-lg text-gray-300 cursor-not-allowed bg-white border border-gray-200 text-[12px]">
                <i class="fas fa-chevron-left"></i>
            </span>
        @else
            <a href="{{ $paginator->previousPageUrl() }}"
               class="inline-flex items-center justify-center w-8 h-8 rounded-lg text-gray-500 bg-white border border-gray-200 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-600 transition-all text-[12px]">
                <i class="fas fa-chevron-left"></i>
            </a>
        @endif

        {{-- Page Numbers --}}
        @foreach($paginator->getUrlRange(
            max(1, $paginator->currentPage() - 2),
            min($paginator->lastPage(), $paginator->currentPage() + 2)
        ) as $page => $url)

            @if($page == 1 && $paginator->currentPage() > 4)
                <a href="{{ $paginator->url(1) }}"
                   class="inline-flex items-center justify-center w-8 h-8 rounded-lg text-[12.5px] font-medium
                          text-gray-600 bg-white border border-gray-200 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-600 transition-all">
                    1
                </a>
                @if($paginator->currentPage() > 5)
                    <span class="px-1 text-gray-400 text-sm select-none">…</span>
                @endif
            @endif

            @if($page == $paginator->currentPage())
                <span class="inline-flex items-center justify-center w-8 h-8 rounded-lg text-[12.5px] font-bold text-white"
                      style="background: linear-gradient(135deg, #2563eb, #1d4ed8); box-shadow: 0 2px 8px rgba(37,99,235,0.35);">
                    {{ $page }}
                </span>
            @else
                <a href="{{ $url }}"
                   class="inline-flex items-center justify-center w-8 h-8 rounded-lg text-[12.5px] font-medium
                          text-gray-600 bg-white border border-gray-200 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-600 transition-all">
                    {{ $page }}
                </a>
            @endif

            @if($page == $paginator->lastPage() - 1 && $paginator->currentPage() < $paginator->lastPage() - 3)
                <span class="px-1 text-gray-400 text-sm select-none">…</span>
                <a href="{{ $paginator->url($paginator->lastPage()) }}"
                   class="inline-flex items-center justify-center w-8 h-8 rounded-lg text-[12.5px] font-medium
                          text-gray-600 bg-white border border-gray-200 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-600 transition-all">
                    {{ $paginator->lastPage() }}
                </a>
            @endif

        @endforeach

        {{-- Next --}}
        @if($paginator->hasMorePages())
            <a href="{{ $paginator->nextPageUrl() }}"
               class="inline-flex items-center justify-center w-8 h-8 rounded-lg text-gray-500 bg-white border border-gray-200 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-600 transition-all text-[12px]">
                <i class="fas fa-chevron-right"></i>
            </a>
        @else
            <span class="inline-flex items-center justify-center w-8 h-8 rounded-lg text-gray-300 cursor-not-allowed bg-white border border-gray-200 text-[12px]">
                <i class="fas fa-chevron-right"></i>
            </span>
        @endif

    </nav>
</div>

@endif