{{-- ═══════════════════════════════════════════════════════════════
     partials/admin/breadcrumbs.blade.php

     CARA PAKAI di view masing-masing:

     @section('breadcrumb')
         @include('partials.admin.breadcrumbs', [
             'crumbs' => [
                 ['label' => 'Produk',  'url' => route('products.index')],
                 ['label' => 'Tambah',  'url' => null],   {{-- null = halaman aktif, tidak ada link --}}
             ]
         ])
     @endsection

     Atau untuk halaman tunggal (tanpa parent):
     @section('breadcrumb')
         @include('partials.admin.breadcrumbs', [
             'crumbs' => [
                 ['label' => 'Dashboard', 'url' => null],
             ]
         ])
     @endsection
═══════════════════════════════════════════════════════════════ --}}

@if(isset($crumbs) && count($crumbs))

<nav aria-label="Breadcrumb" class="flex items-center gap-1 text-[12px] min-w-0 flex-wrap">

    {{-- Home icon --}}
    <a href="{{ route('dashboard') }}"
       class="shrink-0 text-gray-400 hover:text-blue-600 transition-colors"
       title="Dashboard">
        <i class="fas fa-home text-[11px]"></i>
    </a>

    @foreach($crumbs as $i => $crumb)

        {{-- Separator --}}
        <span class="shrink-0 text-gray-300 select-none">
            <i class="fas fa-chevron-right text-[8px]"></i>
        </span>

        @if($loop->last || is_null($crumb['url'] ?? null))
            {{-- Active / last crumb: no link --}}
            <span class="font-semibold text-gray-700 truncate max-w-[160px]" aria-current="page">
                {{ $crumb['label'] }}
            </span>
        @else
            {{-- Parent crumb: clickable --}}
            <a href="{{ $crumb['url'] }}"
               class="text-gray-400 hover:text-blue-600 transition-colors truncate max-w-[120px]">
                {{ $crumb['label'] }}
            </a>
        @endif

    @endforeach

</nav>

@endif